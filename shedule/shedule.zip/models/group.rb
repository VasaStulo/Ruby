# frozen_string_literal: true

# The class of groups with two attributes

Group = Struct.new(:id, :name)
