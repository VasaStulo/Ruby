# frozen_string_literal: true

# A class for recording an item with seven attributes
Lesson = Struct.new(:id, :day, :number, :group, :name, :teacher, :cabinet)
