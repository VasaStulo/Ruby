# frozen_string_literal: true

Reader = Struct.new(:id, :surname, :name, :patronymic, :birthday, :own_books_list)
